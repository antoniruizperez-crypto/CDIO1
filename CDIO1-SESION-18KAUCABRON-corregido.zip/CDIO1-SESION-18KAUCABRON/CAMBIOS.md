# Cambios realizados en la revisión

## Archivos que estaban mal (copias de otro archivo)
- `sesion5.py` era idéntico a `shoreline_utils.py` → el paso 1 del panel no hacía nada y aun así decía «ÉXITO».
  **Reconstruido** a partir del Readme y de lo que esperan los demás scripts.
- `error_estimator.py` era idéntico a `descarga_copernicus.py`.
  **Reconstruido** (reutiliza las funciones de `calculate_erosion.py`).
- `projects/costa_principal/output` era un archivo de 1 byte en vez de una carpeta (nada podía escribir ahí).

> Si tenéis las versiones originales de `sesion5.py` / `error_estimator.py`, conservadlas: las de aquí son
> reconstrucciones funcionales, no el código original. `sesion5.py` no incluye el modo de recortes de calibración (Shadnagar).

## paneldecontrol.py (reescrito)
- Usa el mismo Python que el panel (`sys.executable`) y ejecuta desde la carpeta del proyecto.
- Salida en tiempo real (`-u`) y en UTF-8; antes podía quedar en blanco o romperse con acentos.
- Consola actualizada de forma segura desde el hilo de Tk (cola + `after`).
- Credenciales de Copernicus por variables de entorno; confirmación antes de descargar.
- Un solo proceso a la vez, botón «Detener», validación de fechas/parámetros, aviso si faltan datos del paso anterior.
- Pasos añadidos: validación RMSE, comprobación de entorno, abrir resultados. Fechas por defecto 2017-2024 (las que esperan EDA/LSTM).

## calculate_erosion.py
- La separación media entre transectos se multiplicaba por el nº de fechas.
- La línea de cada fecha se dibujaba una vez por transecto (lentísimo).
- Con varias intersecciones se perdía el signo de la distancia.
- La spline usaba los puntos ordenados por coordenada (`np.unique`) y no a lo largo de la costa.
- Con ground truth la referencia no se recortaba al AOI de forma consistente.
- Las cachés `.pkl` no se invalidaban al cambiar los datos (ahora llevan una huella).
- Guarda `transects_overview.png`; `--no-plot` ya no bloquea.

## Otros
- `analyze.py`, `eda_and_parametric_models.py`, `forecasting_lstm.py`: rutas independientes del directorio de trabajo,
  opción `--no-plot`, mensajes claros si faltan datos o TensorFlow, y control de series demasiado cortas.
