"""
Procesamiento de productos Sentinel-2 L2A: RGB, NDWI y máscaras de agua.

Dependencias:
    pip install numpy pandas rasterio geopandas scikit-image matplotlib tqdm

Entrada:
    Imagenes/zips_entrada/*.zip   (descargados con descarga_copernicus.py)

Qué hace con cada ZIP L2A:
    1. Calcula la nubosidad de la escena a partir de la SCL (clases 8, 9 y 10)
       y descarta los productos que superan el límite.
    2. Lee B02, B03, B04 y B08 (10 m) directamente del ZIP, recortadas al
       polígono del proyecto más un margen.
    3. Calcula NDWI = (verde - NIR) / (verde + NIR).
    4. Umbral fijo -> máscara binaria agua (1) / tierra (0).
    5. Apertura morfológica (opening) para eliminar regiones de agua pequeñas.
    6. Guarda la máscara y los productos de inspección y registra el proceso.
    7. Mueve el ZIP a Imagenes/zips_procesados/ (salvo --no-mover).

Salidas:
    projects/<proyecto>/output/estimated_waterbodies_images/*_water_mask.tif
        GeoTIFF uint8: 0 = tierra, 1 = agua, 255 = sin datos (nodata).
        Es la entrada de extract_shorelines.py.
    Imagenes/resultados/   RGB, NDWI (png y GeoTIFF) y comparación del opening.
    Imagenes/registro_procesamiento.csv

Uso:
    python sesion5.py
    python sesion5.py -p costa_principal --nubosidad 40 --umbral 0.0

Limitaciones (iguales a las descritas en el Readme):
    - Umbral fijo, sin modelo entrenado.
    - La nubosidad se calcula sobre toda la escena, no sobre el polígono.
    - La SCL no se usa como máscara de exclusión del NDWI.
"""

import argparse
import re
import shutil
import sys
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # nunca abre ventanas: se ejecuta desde el panel

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio.enums import Resampling
from rasterio.errors import WindowError
from rasterio.windows import Window, from_bounds
from skimage.morphology import disk, opening
from tqdm import tqdm

import shoreline_utils as utils


NOMBRE_PROYECTO = "costa_principal"

CARPETA_ENTRADA = utils.images_path("zips_entrada")
CARPETA_PROCESADOS = utils.images_path("zips_procesados")
CARPETA_RESULTADOS = utils.images_path("resultados")
ARCHIVO_REGISTRO = utils.images_path("registro_procesamiento.csv")

NUBOSIDAD_MAX_ESCENA = 40.0
NDWI_UMBRAL = 0.0
OPENING_RADIO = 1          # píxeles; 0 desactiva la apertura
MARGEN_M = 300.0           # margen alrededor del polígono al recortar
SCL_NUBES = (8, 9, 10)     # nube media, nube alta y cirro
NODATA_MASCARA = 255

# Los productos con baseline >= 04.00 restan 1000 a los números digitales.
BASELINE_OFFSET = 400
OFFSET_BOA = 1000
ESCALA = 10000.0

PATRON_PRODUCTO = re.compile(
    r"^(S2[ABC])_MSIL(1C|2A)_(\d{8}T\d{6})_N(\d{4})_R\d+_T[A-Z0-9]{5}_"
)

CAMPOS_REGISTRO = [
    "producto", "fecha", "satelite", "nubosidad_scl", "estado",
    "umbral_ndwi", "opening_radio", "agua_pct", "mascara", "error",
]


# ---------------------------------------------------------------------------
# Lectura desde el ZIP
# ---------------------------------------------------------------------------

def ruta_vsizip(zip_path, interno):
    return f"/vsizip/{Path(zip_path).resolve().as_posix()}/{interno}"


def localizar_bandas(zip_path):
    """Devuelve {'B02': ruta_interna, ..., 'SCL': ruta_interna}."""
    with zipfile.ZipFile(zip_path) as zf:
        nombres = zf.namelist()

    patrones = {
        "B02": r"IMG_DATA/R10m/.*_B02_10m\.jp2$",
        "B03": r"IMG_DATA/R10m/.*_B03_10m\.jp2$",
        "B04": r"IMG_DATA/R10m/.*_B04_10m\.jp2$",
        "B08": r"IMG_DATA/R10m/.*_B08_10m\.jp2$",
        "SCL": r"IMG_DATA/R20m/.*_SCL_20m\.jp2$",
    }

    bandas = {}
    for clave, patron in patrones.items():
        encontrados = [n for n in nombres if re.search(patron, n)]
        if not encontrados:
            raise FileNotFoundError(
                f"El ZIP no contiene la banda {clave} ({patron})."
            )
        bandas[clave] = encontrados[0]

    return bandas


def nubosidad_scl(zip_path, interno, decimar=4):
    """Porcentaje de píxeles válidos de la escena clasificados como nube."""
    with rasterio.open(ruta_vsizip(zip_path, interno)) as src:
        alto = max(1, src.height // decimar)
        ancho = max(1, src.width // decimar)
        scl = src.read(
            1,
            out_shape=(alto, ancho),
            resampling=Resampling.nearest,
        )

    validos = scl != 0
    if not validos.any():
        return 100.0

    return float(np.isin(scl[validos], SCL_NUBES).mean() * 100.0)


def leer_recorte(zip_path, bandas, aoi, margen):
    """
    Lee B02, B03, B04 y B08 en la misma ventana (AOI + margen).
    Devuelve (dict de arrays, transform, crs).
    Lanza WindowError si el AOI queda fuera de la escena.
    """
    arrays = {}
    transform = crs = ventana = None

    for clave in ("B02", "B03", "B04", "B08"):
        with rasterio.open(ruta_vsizip(zip_path, bandas[clave])) as src:
            if ventana is None:
                crs = src.crs
                izq, abj, der, arr = aoi.to_crs(crs).total_bounds
                ventana = from_bounds(
                    izq - margen, abj - margen, der + margen, arr + margen,
                    transform=src.transform,
                )
                ventana = ventana.round_offsets(op="floor").round_lengths(
                    op="ceil"
                )
                ventana = ventana.intersection(
                    Window(0, 0, src.width, src.height)
                )
                transform = src.window_transform(ventana)

            arrays[clave] = src.read(1, window=ventana)

    return arrays, transform, crs


# ---------------------------------------------------------------------------
# Cálculo
# ---------------------------------------------------------------------------

def a_reflectancia(dn, baseline):
    dn = dn.astype("float32")
    offset = OFFSET_BOA if baseline >= BASELINE_OFFSET else 0
    return np.clip((dn - offset) / ESCALA, 0, None)


def calcular_ndwi(arrays, baseline):
    verde = a_reflectancia(arrays["B03"], baseline)
    nir = a_reflectancia(arrays["B08"], baseline)

    # DN == 0 es "sin datos" (fuera de la huella del producto).
    validos = (arrays["B03"] > 0) & (arrays["B08"] > 0)

    suma = verde + nir
    validos &= suma > 0

    ndwi = np.full(verde.shape, np.nan, dtype="float32")
    ndwi[validos] = (verde[validos] - nir[validos]) / suma[validos]

    return ndwi, validos


def mascara_agua(ndwi, validos, umbral, radio):
    agua = (ndwi > umbral) & validos
    limpia = agua

    if radio > 0:
        limpia = opening(agua, disk(radio)).astype(bool) & validos

    return agua, limpia


# ---------------------------------------------------------------------------
# Escritura de resultados
# ---------------------------------------------------------------------------

def guardar_mascara(mascara, validos, transform, crs, ruta):
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)

    datos = mascara.astype("uint8")
    datos[~validos] = NODATA_MASCARA

    with rasterio.open(
        ruta, "w",
        driver="GTiff",
        height=datos.shape[0],
        width=datos.shape[1],
        count=1,
        dtype="uint8",
        crs=crs,
        transform=transform,
        nodata=NODATA_MASCARA,
        compress="deflate",
    ) as dst:
        dst.write(datos, 1)


def guardar_ndwi_tif(ndwi, transform, crs, ruta):
    with rasterio.open(
        ruta, "w",
        driver="GTiff",
        height=ndwi.shape[0],
        width=ndwi.shape[1],
        count=1,
        dtype="float32",
        crs=crs,
        transform=transform,
        nodata=np.nan,
        compress="deflate",
    ) as dst:
        dst.write(ndwi, 1)


def guardar_png_rgb(arrays, baseline, ruta):
    rgb = np.dstack([
        a_reflectancia(arrays[b], baseline) for b in ("B04", "B03", "B02")
    ])
    rgb = np.clip(rgb / 0.3, 0, 1) ** (1 / 1.8)
    plt.imsave(ruta, rgb)


def guardar_png_ndwi(ndwi, ruta):
    plt.imsave(ruta, ndwi, cmap="RdYlBu", vmin=-1, vmax=1)


def guardar_comparacion(antes, despues, titulo, ruta):
    fig, ejes = plt.subplots(1, 2, figsize=(14, 4))
    for eje, datos, nombre in (
        (ejes[0], antes, "Antes del opening"),
        (ejes[1], despues, "Después del opening"),
    ):
        eje.imshow(datos, cmap="gray", vmin=0, vmax=1, interpolation="nearest")
        eje.set_title(nombre)
        eje.axis("off")
    fig.suptitle(titulo, fontsize=9)
    fig.tight_layout()
    fig.savefig(ruta, dpi=120)
    plt.close(fig)


def actualizar_registro(filas, ruta=ARCHIVO_REGISTRO):
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)

    nuevo = pd.DataFrame(filas, columns=CAMPOS_REGISTRO)

    if ruta.is_file():
        try:
            anterior = pd.read_csv(ruta)
            nuevo = pd.concat([anterior, nuevo], ignore_index=True)
        except Exception:
            pass

    nuevo = nuevo.drop_duplicates(subset="producto", keep="last")
    nuevo.to_csv(ruta, index=False)


# ---------------------------------------------------------------------------
# Flujo principal
# ---------------------------------------------------------------------------

def cargar_aoi(project_dir):
    import geopandas as gpd

    ruta = project_dir / "input" / "polygon.geojson"
    if not ruta.is_file():
        raise FileNotFoundError(f"No existe el polígono del proyecto: {ruta}")

    aoi = gpd.read_file(ruta)
    if aoi.empty:
        raise ValueError("El polígono del proyecto está vacío.")
    if aoi.crs is None:
        aoi = aoi.set_crs("EPSG:4326")

    return aoi


def procesar_zip(zip_path, aoi, salida_mascaras, umbral, radio, nubes_max):
    """Devuelve la fila del registro. Lanza excepciones solo por errores."""
    zip_path = Path(zip_path)
    producto = zip_path.stem

    coincide = PATRON_PRODUCTO.match(producto)
    fila = {campo: "" for campo in CAMPOS_REGISTRO}
    fila["producto"] = producto
    fila["umbral_ndwi"] = umbral
    fila["opening_radio"] = radio

    if not coincide:
        fila["estado"] = "nombre_no_reconocido"
        return fila

    satelite, nivel, instante, baseline = coincide.groups()
    fila["satelite"] = satelite
    fila["fecha"] = f"{instante[:4]}-{instante[4:6]}-{instante[6:8]}"

    if nivel != "2A":
        fila["estado"] = "omitido_no_L2A"
        return fila

    bandas = localizar_bandas(zip_path)

    nubes = nubosidad_scl(zip_path, bandas["SCL"])
    fila["nubosidad_scl"] = round(nubes, 2)

    if nubes > nubes_max:
        fila["estado"] = "omitido_nubosidad"
        return fila

    try:
        arrays, transform, crs = leer_recorte(
            zip_path, bandas, aoi, MARGEN_M
        )
    except WindowError:
        fila["estado"] = "fuera_de_escena"
        return fila

    baseline = int(baseline)
    ndwi, validos = calcular_ndwi(arrays, baseline)

    if not validos.any():
        fila["estado"] = "sin_datos_validos"
        return fila

    agua, limpia = mascara_agua(ndwi, validos, umbral, radio)

    mascara_tif = salida_mascaras / f"{producto}_water_mask.tif"
    guardar_mascara(limpia, validos, transform, crs, mascara_tif)

    CARPETA_RESULTADOS.mkdir(parents=True, exist_ok=True)
    guardar_ndwi_tif(ndwi, transform, crs, CARPETA_RESULTADOS / f"{producto}_ndwi.tif")
    guardar_png_rgb(arrays, baseline, CARPETA_RESULTADOS / f"{producto}_rgb.png")
    guardar_png_ndwi(ndwi, CARPETA_RESULTADOS / f"{producto}_ndwi.png")
    guardar_comparacion(
        agua, limpia, producto,
        CARPETA_RESULTADOS / f"{producto}_opening_antes_despues.png",
    )

    fila["agua_pct"] = round(float(limpia[validos].mean() * 100.0), 2)
    fila["mascara"] = str(mascara_tif)
    fila["estado"] = "procesado"
    return fila


def main(project, nubosidad, umbral, radio, entrada, mover):
    project_dir = utils.project_path(project)
    salida_mascaras = project_dir / "output" / "estimated_waterbodies_images"

    entrada = Path(entrada)
    if not entrada.is_dir():
        raise SystemExit(
            f"No existe la carpeta de entrada: {entrada}\n"
            "Descarga antes los productos con descarga_copernicus.py."
        )

    zips = sorted(entrada.glob("*.zip"))
    if not zips:
        raise SystemExit(f"No hay ZIP que procesar en {entrada}")

    # `output` debe ser una carpeta; si existe como archivo, no se puede escribir.
    out_dir = project_dir / "output"
    if out_dir.exists() and not out_dir.is_dir():
        raise SystemExit(
            f"{out_dir} es un archivo, no una carpeta. Elimínalo y vuelve a ejecutar."
        )

    salida_mascaras.mkdir(parents=True, exist_ok=True)
    aoi = cargar_aoi(project_dir)

    filas = []
    errores = 0

    for zip_path in tqdm(zips, desc="Procesando ZIPs", file=sys.stdout):
        try:
            fila = procesar_zip(
                zip_path, aoi, salida_mascaras, umbral, radio, nubosidad
            )
        except Exception as error:
            errores += 1
            fila = {campo: "" for campo in CAMPOS_REGISTRO}
            fila.update(
                producto=zip_path.stem,
                estado="error",
                error=str(error),
            )
            print(f"\nERROR en {zip_path.name}: {error}")

        filas.append(fila)
        print(f"{zip_path.name}: {fila['estado']}")

        # Solo se mueven los productos tratados; los omitidos por nubosidad
        # o con error se quedan para poder revisarlos.
        if mover and fila["estado"] == "procesado":
            CARPETA_PROCESADOS.mkdir(parents=True, exist_ok=True)
            shutil.move(str(zip_path), str(CARPETA_PROCESADOS / zip_path.name))

    actualizar_registro(filas)

    estados = pd.Series([f["estado"] for f in filas]).value_counts()
    print("\nResumen:")
    for estado, n in estados.items():
        print(f"  {estado}: {n}")
    print(f"Máscaras en: {salida_mascaras}")
    print(f"Registro: {ARCHIVO_REGISTRO}")

    if errores:
        raise SystemExit(1)
    if "procesado" not in estados.index:
        print("Aviso: ninguna escena produjo máscara.")
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Procesa ZIP Sentinel-2 L2A: NDWI y máscaras de agua."
    )
    parser.add_argument("-p", "--project", default=NOMBRE_PROYECTO)
    parser.add_argument(
        "--nubosidad", type=float, default=NUBOSIDAD_MAX_ESCENA,
        help="Nubosidad máxima de la escena (%%) según la SCL.",
    )
    parser.add_argument("--umbral", type=float, default=NDWI_UMBRAL)
    parser.add_argument(
        "--opening-radio", type=int, default=OPENING_RADIO,
        help="Radio de la apertura morfológica en píxeles (0 = desactivada).",
    )
    parser.add_argument("--entrada", default=str(CARPETA_ENTRADA))
    parser.add_argument(
        "--no-mover", action="store_true",
        help="No mover los ZIP procesados a zips_procesados.",
    )
    args = parser.parse_args()

    if not 0 <= args.nubosidad <= 100:
        parser.error("--nubosidad debe estar entre 0 y 100.")
    if args.opening_radio < 0:
        parser.error("--opening-radio no puede ser negativo.")

    main(
        args.project,
        args.nubosidad,
        args.umbral,
        args.opening_radio,
        args.entrada,
        mover=not args.no_mover,
    )
