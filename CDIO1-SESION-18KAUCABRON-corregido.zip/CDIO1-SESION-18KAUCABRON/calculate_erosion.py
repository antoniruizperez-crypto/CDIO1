import argparse
import hashlib
import pickle
import sys
from datetime import datetime
from pathlib import Path

import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from scipy.interpolate import splev, splprep
from shapely.geometry import LineString, MultiLineString, Point
from shapely.ops import linemerge

import shoreline_utils as utils


SPATIAL_SPACING = 10
TRANSECT_LENGTH = 100


def closest_ground_truth_file(ground_truth_dir, target_date):
    base = Path(ground_truth_dir).expanduser().resolve()
    if not base.is_dir():
        print(f"Error: {base} is not a directory", file=sys.stderr)
        sys.exit(1)

    dated_files = []
    for csv_file in base.glob("*.csv"):
        date = utils.extract_date(csv_file.name)
        if date is not None:
            dated_files.append((date, csv_file))

    if not dated_files:
        raise FileNotFoundError(f"No dated CSV files found in {base}")

    return min(dated_files, key=lambda row: abs(row[0] - target_date))


def load_reference(project_dir, shorelines, sorted_dates_str, ground_truth):
    if ground_truth is None:
        reference_date = sorted_dates_str[0]
        reference_coords = shorelines[reference_date]
        return reference_date, reference_coords, 1, False

    first_date = datetime.strptime(sorted_dates_str[0], "%Y-%m-%d").date()
    reference_date, gt_csv_path = closest_ground_truth_file(ground_truth, first_date)
    reference_coords = (
        pd.read_csv(
            gt_csv_path,
            sep=r"[\s,]+",
            engine="python",
            comment="%",
            header=None,
            usecols=[0, 1],
        )
        .apply(pd.to_numeric, errors="coerce")
        .dropna()
        .to_numpy(dtype=float)
    )

    gt_coords = utils.load_coords_csv(gt_csv_path)
    utils.export_coords_to_kmz(gt_coords, gt_csv_path.with_suffix(".kmz"))

    return reference_date.isoformat(), reference_coords, 0, True


def signed_intersection_distance(intersection, px, py, normal):
    """
    Distancia con signo entre el punto de referencia (px, py) y la
    intersección del transecto con la costa. Signo positivo: en el
    sentido de la normal. Si hay varias intersecciones se usa la más
    cercana (conservando su signo).
    """
    if intersection is None or intersection.is_empty:
        return np.nan

    if isinstance(intersection, Point):
        candidates = [intersection]
    elif hasattr(intersection, "geoms"):
        candidates = [g for g in intersection.geoms if isinstance(g, Point)]
    else:
        # LineString (transecto colineal con la costa): no hay corte único.
        return np.nan

    if not candidates:
        return np.nan

    reference = Point(px, py)
    nearest = min(candidates, key=reference.distance)
    signed_vector = np.array([nearest.x - px, nearest.y - py])
    distance = float(np.linalg.norm(signed_vector))

    if np.dot(signed_vector, normal) < 0:
        distance = -distance

    return distance


def coords_hash(coords):
    """Huella corta de un conjunto de puntos, para invalidar cachés."""
    data = np.ascontiguousarray(np.asarray(coords, dtype=float))
    return hashlib.md5(data.tobytes()).hexdigest()[:8]


def ordered_line_coords(line):
    """
    Coordenadas (N, 2) de una línea en orden de recorrido, sin puntos
    consecutivos repetidos. Si el recorte con el AOI dejó varios tramos
    se fusionan y, si siguen separados, se usa el más largo.
    """
    if isinstance(line, MultiLineString):
        merged = linemerge(line)
        line = (
            max(merged.geoms, key=lambda g: g.length)
            if isinstance(merged, MultiLineString)
            else merged
        )

    if not isinstance(line, LineString) or line.is_empty:
        raise ValueError("La línea de referencia está vacía.")

    coords = np.asarray(line.coords, dtype=float)[:, :2]
    keep = np.ones(len(coords), dtype=bool)
    keep[1:] = np.any(np.diff(coords, axis=0) != 0, axis=1)
    return coords[keep]


def load_project_aoi(project_dir):
    """
    AOI del proyecto en el CRS de las máscaras. Si todavía no hay máscaras
    se usa EPSG:32631 (UTM 31N), el CRS de los ground truth del proyecto.
    """
    geojson_path = project_dir / "input" / "polygon.geojson"
    if not geojson_path.exists():
        return None

    mask_dir = project_dir / "output" / "estimated_waterbodies_images"
    first_mask = next(mask_dir.glob("*.tif"), None) if mask_dir.is_dir() else None

    aoi = gpd.read_file(geojson_path).set_crs(4326, allow_override=True)

    if first_mask is None:
        return aoi.to_crs(32631)

    with rasterio.open(first_mask) as src:
        return aoi.to_crs(src.crs)


def load_cached_line(cache_path, builder):
    if cache_path.exists() and cache_path.stat().st_size > 0:
        try:
            with open(cache_path, "rb") as f:
                return pickle.load(f)
        except Exception:
            pass  # caché corrupta: se reconstruye

    line = builder()
    with open(cache_path, "wb") as f:
        pickle.dump(line, f)
    return line


def main(project, ground_truth=None, show_plot=True):
    project_dir = utils.project_path(project)
    output_dir = project_dir / "output" / "estimated_erosion_accretion"
    output_dir.mkdir(parents=True, exist_ok=True)

    if not show_plot:
        plt.switch_backend("Agg")

    csv_path = project_dir / "output" / "estimated_waterbodies_edges" / "all_shorelines.csv"
    if not csv_path.is_file():
        raise SystemExit(
            f"No existe {csv_path}. Ejecuta antes extract_shorelines.py."
        )

    df = pd.read_csv(csv_path)
    if df.empty:
        raise SystemExit(f"{csv_path} no contiene puntos de costa.")

    shorelines = {date: group[["x", "y"]].values for date, group in df.groupby("date")}
    sorted_dates_str = sorted(shorelines.keys())

    reference_date, reference_coords, start_index, ordered = load_reference(
        project_dir, shorelines, sorted_dates_str, ground_truth
    )

    reference_date_underscores = str(reference_date).replace("-", "_")
    reference_xy = np.column_stack((reference_coords[:, 0], reference_coords[:, 1]))
    line_path = output_dir / f"ref_{reference_date_underscores}_{coords_hash(reference_xy)}.pkl"

    def build_reference():
        line = utils.build_ordered_linestring(reference_xy, ordered)
        if ground_truth is not None:
            aoi = load_project_aoi(project_dir)
            if aoi is not None:
                aoi_geom = aoi.union_all() if hasattr(aoi, "union_all") else aoi.unary_union
                line = line.intersection(aoi_geom)
        return line

    reference_line = load_cached_line(line_path, build_reference)

    # La spline debe seguir la línea ORDENADA (y recortada al AOI), no los
    # puntos ordenados por coordenada (np.unique), que rompe la geometría.
    ref_coords = ordered_line_coords(reference_line)
    if len(ref_coords) < 4:
        raise SystemExit("La costa de referencia tiene muy pocos puntos.")

    shoreline_length = reference_line.length
    n_points = max(2, int(shoreline_length / SPATIAL_SPACING))

    tck, _ = splprep([ref_coords[:, 0], ref_coords[:, 1]], s=0)
    unew = np.linspace(0, 1, num=n_points)
    x_smooth, y_smooth = splev(unew, tck)
    dx, dy = splev(unew, tck, der=1)

    # Separación media entre transectos (se calcula una sola vez).
    dist_reference = float(np.sum(np.hypot(np.diff(x_smooth), np.diff(y_smooth))))

    # Normales unitarias de cada transecto.
    normals = np.column_stack((-np.asarray(dy), np.asarray(dx)))
    norms = np.linalg.norm(normals, axis=1)
    norms[norms == 0] = np.nan
    normals = normals / norms[:, None]

    fig, ax = plt.subplots(figsize=(12, 8))
    x_ref, y_ref = (
        ref_coords[:, 0],
        ref_coords[:, 1],
    )
    ax.plot(x_ref, y_ref, "k--", label=f"Reference shoreline ({reference_date})", alpha=0.5)
    ax.plot(x_smooth, y_smooth, "b", label=f"Smoothed shoreline ({reference_date})", alpha=0.7)

    half = TRANSECT_LENGTH / 2
    for i in range(len(unew)):
        if np.isnan(normals[i]).any():
            continue
        ax.plot(
            [x_smooth[i] - normals[i, 0] * half, x_smooth[i] + normals[i, 0] * half],
            [y_smooth[i] - normals[i, 1] * half, y_smooth[i] + normals[i, 1] * half],
            "g-",
            alpha=0.3,
        )

    distance_results = []
    colors = ["r", "m", "c", "y"]

    for idx, date in enumerate(sorted_dates_str[start_index:]):
        coords = shorelines[date]
        if len(coords) < 2:
            print(f"Skipping shoreline for {date} due to insufficient points.")
            continue

        print(f"Ordering shoreline for {date}...")
        date_underscores = date.replace("-", "_")
        line_cache_path = output_dir / f"line_{date_underscores}_{coords_hash(coords)}.pkl"
        line = load_cached_line(
            line_cache_path,
            lambda coords=coords: utils.build_ordered_linestring(coords, False),
        )
        print("Done")

        # La línea se dibuja una sola vez por fecha (antes se repetía
        # una vez por transecto, con un coste enorme).
        for part_idx, part in enumerate(getattr(line, "geoms", [line])):
            x_line, y_line = part.xy
            ax.plot(
                x_line,
                y_line,
                "--",
                label=date if part_idx == 0 else None,
                color=colors[idx % len(colors)],
            )

        for i in range(len(unew)):
            px, py = x_smooth[i], y_smooth[i]
            normal = normals[i]

            if np.isnan(normal).any():
                distance = np.nan
            else:
                start = (px - normal[0] * half, py - normal[1] * half)
                end = (px + normal[0] * half, py + normal[1] * half)
                transect = LineString([start, end])
                distance = signed_intersection_distance(
                    transect.intersection(line), px, py, normal
                )

            distance_results.append(
                {
                    "date": date,
                    "transect_id": i,
                    "reference_x": px,
                    "reference_y": py,
                    "distance_m": distance,
                }
            )

    if not distance_results:
        plt.close(fig)
        raise SystemExit(
            "No hay fechas que comparar con la referencia. Se necesitan al menos "
            "dos fechas (o una fecha y un ground truth con -g)."
        )

    print(f"Average distance between transects: {dist_reference / max(1, len(unew) - 1):.2f} meters")

    distance_df = pd.DataFrame(distance_results)
    total_transects = distance_df["transect_id"].nunique()

    print(f"Number of transects computed: {len(unew)}")
    print(
        "Number of valid transects with at least one valid distance: "
        f"{distance_df.loc[distance_df['distance_m'].notna(), 'transect_id'].nunique()}"
    )
    print(f"First date in dataset: {distance_df['date'].min()}")
    print(f"Last date in dataset: {distance_df['date'].max()}")
    print(f"Number of distinct dates in dataset: {distance_df['date'].nunique()}")

    summary_df = (
        distance_df.groupby("date")
        .agg(
            avg_distance_m=("distance_m", "mean"),
            median_distance_m=("distance_m", "median"),
            std_distance_m=("distance_m", "std"),
            max_distance_m=("distance_m", "max"),
            min_distance_m=("distance_m", "min"),
            valid_points=("distance_m", lambda values: values.notna().sum()),
        )
        .reset_index()
    )

    summary_df["coverage_ratio"] = summary_df["valid_points"] / total_transects
    summary_df["range_distance_m"] = summary_df["max_distance_m"] - summary_df["min_distance_m"]

    summary_df.to_csv(output_dir / "distances_summary.csv", index=False)
    distance_df.to_csv(output_dir / "shoreline_distances.csv", index=False)

    ax.set_title("Shoreline Geometry and Transect Intersections")
    ax.set_xlabel("X (meters, projected)")
    ax.set_ylabel("Y (meters, projected)")
    ax.legend()
    ax.axis("equal")
    ax.grid(True)
    fig.savefig(output_dir / "transects_overview.png", dpi=150, bbox_inches="tight")

    if show_plot:
        plt.show()
    else:
        plt.close(fig)

    print(f"Resultados guardados en: {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Estimate erosion and accretion from shoreline data.")
    parser.add_argument(
        "-p",
        "--project",
        required=True,
        help="Project name under coastline_estimator/projects.",
    )
    parser.add_argument(
        "-g",
        "--ground-truth",
        help="Path to a folder containing ground truth CSV files to use as a reference.",
    )
    parser.add_argument("--no-plot", action="store_true", help="Write CSV outputs without opening plots.")
    args = parser.parse_args()
    main(args.project, args.ground_truth, show_plot=not args.no_plot)