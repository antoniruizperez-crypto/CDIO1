"""
Panel de control del proyecto CDIO1 (monitorización de la línea de costa).

Lanza los scripts del proyecto con el mismo Python con el que se ejecuta el
panel, desde la carpeta del proyecto, y muestra su salida en la consola.

    python paneldecontrol.py

Notas:
    - Las credenciales de Copernicus se pasan al script de descarga por
      variables de entorno (CDSE_USER / CDSE_PASSWORD); nunca por la línea
      de comandos ni se guardan en disco.
    - Solo se ejecuta un proceso a la vez. El botón «Detener» lo cancela.
"""

import os
import queue
import re
import signal
import subprocess
import sys
import threading
import tkinter as tk
from datetime import date
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk

BASE_DIR = Path(__file__).resolve().parent
PYTHON = sys.executable
DEFAULT_PROJECT = "costa_principal"

MODULOS_ENTORNO = [
    ("numpy", "numpy"), ("pandas", "pandas"), ("scipy", "scipy"),
    ("shapely", "shapely"), ("pyproj", "pyproj"), ("rasterio", "rasterio"),
    ("geopandas", "geopandas"), ("skimage", "scikit-image"),
    ("tqdm", "tqdm"), ("matplotlib", "matplotlib"),
    ("sklearn", "scikit-learn"), ("requests", "requests"),
    ("tensorflow", "tensorflow"),
]


# Líneas de salida que merecen resaltarse como error.
ERROR_LINE = re.compile(
    r"^\s*(traceback|error\b|\w*error:|\[error|\[excepci)|no existe|no se pudo|faltan?\b",
    re.IGNORECASE,
)


class CoastalControlApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Panel de Control - Monitorización y Pronóstico de Costa (CDIO1)")
        self.root.geometry("1100x780")
        self.root.minsize(900, 600)

        self.proc = None
        self.messages = queue.Queue()
        self.action_buttons = []
        self._last_was_progress = False
        self._on_success = None
        self._stopped = False

        self.var_project = tk.StringVar(value=DEFAULT_PROJECT)
        self.var_status = tk.StringVar(value="Listo")

        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.create_header()
        self.create_tabs()
        self.create_console()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(100, self.poll_messages)

        self.log(f"Python: {PYTHON}")
        self.log(f"Carpeta de trabajo: {BASE_DIR}")

    # ------------------------------------------------------------------
    # Rutas del proyecto
    # ------------------------------------------------------------------

    def project(self):
        return self.var_project.get().strip() or DEFAULT_PROJECT

    def project_dir(self):
        return BASE_DIR / "projects" / self.project()

    def output_dir(self):
        return self.project_dir() / "output"

    # ------------------------------------------------------------------
    # Interfaz
    # ------------------------------------------------------------------

    def add_button(self, parent, text, command, **pack):
        button = ttk.Button(parent, text=text, command=command)
        self.action_buttons.append(button)
        return button

    def create_header(self):
        frame = ttk.Frame(self.root, padding=10)
        frame.pack(fill="x", padx=10, pady=(10, 0))

        ttk.Label(
            frame,
            text="Panel de Control - Proyecto Línea de Costa Castelldefels",
            font=("Helvetica", 16, "bold"),
        ).pack(side="left")

        right = ttk.Frame(frame)
        right.pack(side="right")
        ttk.Label(right, text="Proyecto:").pack(side="left", padx=(0, 5))
        ttk.Entry(right, textvariable=self.var_project, width=18).pack(side="left")

    def create_tabs(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=False, padx=10, pady=5)

        tabs = [
            ("1. Adquisición CDSE", self.build_descarga_tab),
            ("2. Procesamiento y Extracción", self.build_procesamiento_tab),
            ("3. EDA y Modelos Paramétricos", self.build_analisis_tab),
            ("4. Pronóstico LSTM (2025)", self.build_lstm_tab),
        ]
        for title, builder in tabs:
            frame = ttk.Frame(self.notebook, padding=15)
            self.notebook.add(frame, text=title)
            builder(frame)

    def field(self, parent, row, label, default, width=20, show=None):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        var = tk.StringVar(value=default)
        ttk.Entry(parent, textvariable=var, width=width, show=show).grid(
            row=row, column=1, sticky="w", padx=10
        )
        return var

    def build_descarga_tab(self, tab):
        ttk.Label(
            tab,
            text="Descarga de imágenes Sentinel-2 L2A desde Copernicus Data Space Ecosystem:",
            font=("Helvetica", 11, "bold"),
        ).pack(anchor="w", pady=5)

        form = ttk.Frame(tab)
        form.pack(fill="x", pady=5)

        # El análisis posterior (modelos y LSTM) necesita varios años de datos.
        self.var_inicio = self.field(form, 0, "Fecha Inicio (YYYY-MM-DD):", "2017-01-01")
        self.var_fin = self.field(form, 1, "Fecha Fin (YYYY-MM-DD):", "2024-12-31")
        self.var_nube = self.field(form, 2, "Nubosidad Máxima Escena (%):", "40.0")
        self.var_user = self.field(form, 3, "Usuario CDSE (correo):", os.environ.get("CDSE_USER", ""), width=32)
        self.var_pass = self.field(form, 4, "Contraseña CDSE:", "", width=32, show="*")

        ttk.Label(
            tab,
            text="Si dejas usuario y contraseña vacíos se usarán CDSE_USER/CDSE_PASSWORD o el archivo .cdse_credentials.",
            foreground="#555555",
        ).pack(anchor="w")

        buttons = ttk.Frame(tab)
        buttons.pack(fill="x", pady=10)
        for text, cmd in (
            ("Buscar Productos (Solo Listar)", self.run_descarga_listar),
            ("Descargar Productos", self.run_descarga_real),
        ):
            b = self.add_button(buttons, text, cmd)
            b.pack(side="left", padx=5)

    def build_procesamiento_tab(self, tab):
        ttk.Label(
            tab,
            text="Procesamiento de imágenes y extracción del borde costero:",
            font=("Helvetica", 11, "bold"),
        ).pack(anchor="w", pady=5)

        form = ttk.Frame(tab)
        form.pack(fill="x")
        self.var_nube_proc = self.field(form, 0, "Nubosidad máx. SCL (%):", "40.0", width=10)
        self.var_umbral = self.field(form, 1, "Umbral NDWI:", "0.0", width=10)
        self.var_opening = self.field(form, 2, "Radio opening (px):", "1", width=10)
        self.var_closing = self.field(form, 3, "Radio closing (px):", "1", width=10)
        self.var_use_gt = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            form,
            text="Usar ground truth como referencia en el cálculo de distancias",
            variable=self.var_use_gt,
        ).grid(row=4, column=0, columnspan=2, sticky="w", pady=4)

        steps = [
            ("1. Procesar ZIPs (NDWI + Máscaras Binarias) [sesion5.py]", self.run_sesion5),
            ("2. Extraer Bordes de Costa [extract_shorelines.py]", self.run_extract),
            ("3. Calcular Distancias por Transecto [calculate_erosion.py]", self.run_calculate),
            ("4. Visualizar Distancias Extraídas [analyze.py] (cierra las ventanas para continuar)", self.run_analyze),
            ("5. Validar con referencia externa, RMSE [error_estimator.py]", self.run_error),
        ]
        for text, cmd in steps:
            self.add_button(tab, text, cmd).pack(anchor="w", fill="x", pady=3)

    def build_analisis_tab(self, tab):
        ttk.Label(
            tab,
            text="Análisis exploratorio, limpieza de datos y ajuste de 3 modelos paramétricos:",
            font=("Helvetica", 11, "bold"),
        ).pack(anchor="w", pady=5)
        ttk.Label(
            tab,
            text="Filtra transectos con NaNs, elimina outliers (IQR), calcula velocidad/aceleración\n"
                 "y compara 3 modelos: Lineal + FFT, Step (Gloria) + FFT, Sigmoide + FFT.",
        ).pack(anchor="w", pady=5)
        self.add_button(
            tab,
            "Ejecutar Análisis EDA y Ajustar Modelos Paramétricos [eda_and_parametric_models.py]",
            self.run_eda,
        ).pack(anchor="w", fill="x", pady=10)

    def build_lstm_tab(self, tab):
        ttk.Label(
            tab,
            text="Predicción de erosión para Enero - Junio 2025 mediante Red LSTM:",
            font=("Helvetica", 11, "bold"),
        ).pack(anchor="w", pady=5)
        ttk.Label(
            tab,
            text="Entrena una red Deep Learning LSTM mediante ventanas deslizantes\n"
                 "y genera la predicción a 6 meses comparándola con el modelo paramétrico y sus IC del 95%.",
        ).pack(anchor="w", pady=5)
        self.add_button(
            tab,
            "Entrenar LSTM y Generar Pronóstico 2025 [forecasting_lstm.py]",
            self.run_lstm,
        ).pack(anchor="w", fill="x", pady=10)

    def create_console(self):
        bar = ttk.Frame(self.root)
        bar.pack(fill="x", padx=10)

        self.btn_stop = ttk.Button(bar, text="Detener", command=self.stop_process, state="disabled")
        self.btn_stop.pack(side="left", padx=(0, 5))
        ttk.Button(bar, text="Limpiar consola", command=self.clear_console).pack(side="left", padx=5)
        self.add_button(bar, "Comprobar entorno", self.check_environment).pack(side="left", padx=5)
        ttk.Button(bar, text="Abrir carpeta de resultados", command=self.open_results).pack(side="left", padx=5)
        ttk.Label(bar, textvariable=self.var_status).pack(side="right")

        frame = ttk.LabelFrame(self.root, text="Consola de Salida / Registro", padding=10)
        frame.pack(fill="both", expand=True, padx=10, pady=(5, 10))

        self.console = scrolledtext.ScrolledText(
            frame, height=14, bg="#1e1e1e", fg="#d4d4d4",
            insertbackground="#d4d4d4", font=("TkFixedFont", 9),
        )
        self.console.pack(fill="both", expand=True)
        self.console.tag_config("info", foreground="#4ec9b0")
        self.console.tag_config("ok", foreground="#6ae26a")
        self.console.tag_config("error", foreground="#ff6b6b")

    # ------------------------------------------------------------------
    # Consola (solo se toca desde el hilo de Tk)
    # ------------------------------------------------------------------

    def log(self, text, tag=None):
        is_progress = "%|" in text and "\n" not in text
        if is_progress and self._last_was_progress:
            self.console.delete("end-2l", "end-1c")
        self._last_was_progress = is_progress

        if tag is None:
            if ERROR_LINE.search(text):
                tag = "error"
        self.console.insert(tk.END, text + "\n", tag)
        self.console.see(tk.END)

    def clear_console(self):
        self.console.delete("1.0", tk.END)
        self._last_was_progress = False

    def poll_messages(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == "log":
                    self.log(payload)
                elif kind == "done":
                    self.on_process_done(*payload)
        except queue.Empty:
            pass
        self.root.after(100, self.poll_messages)

    # ------------------------------------------------------------------
    # Ejecución de procesos
    # ------------------------------------------------------------------

    def set_busy(self, busy, label=""):
        state = "disabled" if busy else "normal"
        for button in self.action_buttons:
            button.configure(state=state)
        self.btn_stop.configure(state="normal" if busy else "disabled")
        self.var_status.set(f"Ejecutando: {label}" if busy else "Listo")

    def ensure_output_dir(self):
        """`output` debe ser una carpeta; un archivo con ese nombre rompe todo."""
        out = self.output_dir()
        if out.exists() and not out.is_dir():
            if out.stat().st_size > 16:
                messagebox.showerror(
                    "Carpeta output",
                    f"{out} es un archivo con contenido, no una carpeta.\n"
                    "Muévelo o elimínalo manualmente.",
                )
                return False
            out.unlink()
            self.log(f"[AVISO]: {out} era un archivo vacío; se ha sustituido por una carpeta.", "info")
        out.mkdir(parents=True, exist_ok=True)
        return True

    def run_script(self, script, args=(), env=None, requires=None, on_success=None):
        if self.proc is not None:
            messagebox.showinfo("Proceso en curso", "Espera a que termine el proceso actual o pulsa Detener.")
            return

        if not (BASE_DIR / script).is_file():
            messagebox.showerror("Falta el script", f"No se encuentra {script} en {BASE_DIR}")
            return

        if not self.ensure_output_dir():
            return

        if requires:
            problem = requires()
            if problem:
                messagebox.showwarning("Faltan datos de entrada", problem)
                return

        self.launch([PYTHON, "-u", script, *map(str, args)], script, env, on_success)

    def launch(self, cmd, label, env=None, on_success=None):
        full_env = os.environ.copy()
        full_env.update({
            "PYTHONUNBUFFERED": "1",
            "PYTHONIOENCODING": "utf-8",
            "TQDM_MININTERVAL": "1",
        })
        if env:
            full_env.update(env)

        if "-c" in cmd:
            shown = label
        else:
            shown = " ".join(cmd[2:] if cmd[1:2] == ["-u"] else cmd[1:])
        self.log(f"\n[EJECUTANDO]: python {shown}", "info")
        self.set_busy(True, label)
        self._on_success = on_success

        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True

        try:
            self.proc = subprocess.Popen(
                cmd,
                cwd=str(BASE_DIR),
                env=full_env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                **kwargs,
            )
        except Exception as error:
            self.proc = None
            self.set_busy(False)
            self.log(f"[EXCEPCIÓN]: no se pudo lanzar el proceso: {error}", "error")
            return

        proc = self.proc
        self._stopped = False

        def reader():
            try:
                for line in proc.stdout:
                    self.messages.put(("log", line.rstrip()))
            except Exception as error:
                self.messages.put(("log", f"[EXCEPCIÓN]: {error}"))
            finally:
                proc.wait()
                self.messages.put(("done", (proc.returncode,)))

        threading.Thread(target=reader, daemon=True).start()

    def on_process_done(self, returncode):
        self.proc = None
        self.set_busy(False)

        if self._stopped:
            self.log("[DETENIDO]: proceso cancelado por el usuario.", "error")
        elif returncode == 0:
            self.log("[ÉXITO]: Proceso finalizado correctamente.", "ok")
            callback, self._on_success = self._on_success, None
            if callback:
                callback()
        else:
            self.log(f"[ERROR]: El proceso terminó con código {returncode}.", "error")

    def stop_process(self):
        if self.proc is None:
            return
        self._stopped = True
        try:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/T", "/F", "/PID", str(self.proc.pid)],
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
            else:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
        except Exception as error:
            self.log(f"[AVISO]: no se pudo detener el proceso: {error}", "error")

    def on_close(self):
        if self.proc is not None:
            if not messagebox.askyesno("Salir", "Hay un proceso en ejecución. ¿Detenerlo y salir?"):
                return
            self.stop_process()
        self.root.destroy()

    # ------------------------------------------------------------------
    # Utilidades
    # ------------------------------------------------------------------

    def open_path(self, path):
        path = Path(path)
        if not path.exists():
            self.log(f"[AVISO]: no existe {path}", "error")
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(path))  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as error:
            self.log(f"[AVISO]: no se pudo abrir {path}: {error}", "error")

    def open_results(self):
        out = self.output_dir()
        self.open_path(out if out.is_dir() else self.project_dir())

    def open_images(self, *paths):
        for path in paths:
            self.open_path(path)

    def has_files(self, folder, pattern):
        return folder.is_dir() and any(folder.glob(pattern))

    def check_environment(self):
        code = (
            "import sys, importlib\n"
            "print('Python', sys.version.split()[0], '-', sys.executable)\n"
            f"mods = {MODULOS_ENTORNO!r}\n"
            "faltan = []\n"
            "for mod, pip in mods:\n"
            "    try:\n"
            "        m = importlib.import_module(mod)\n"
            "        print(f'  OK     {mod} {getattr(m, \"__version__\", \"\")}')\n"
            "    except Exception as e:\n"
            "        print(f'  FALTA  {mod}  ->  pip install {pip}')\n"
            "        faltan.append(pip)\n"
            "print('Todo instalado.' if not faltan else 'Faltan: ' + ' '.join(faltan))\n"
        )
        if self.proc is not None:
            return
        self.launch([PYTHON, "-u", "-c", code], "comprobar entorno")

    # ------------------------------------------------------------------
    # 1. Descarga
    # ------------------------------------------------------------------

    def validate_download_form(self):
        try:
            inicio = date.fromisoformat(self.var_inicio.get().strip())
            fin = date.fromisoformat(self.var_fin.get().strip())
        except ValueError:
            messagebox.showerror("Fechas no válidas", "Usa el formato YYYY-MM-DD (por ejemplo 2024-01-31).")
            return None
        if inicio > fin:
            messagebox.showerror("Fechas no válidas", "La fecha de inicio es posterior a la de fin.")
            return None
        try:
            nube = float(self.var_nube.get().replace(",", "."))
        except ValueError:
            nube = -1
        if not 0 <= nube <= 100:
            messagebox.showerror("Nubosidad no válida", "Introduce un número entre 0 y 100.")
            return None
        return inicio.isoformat(), fin.isoformat(), str(nube)

    def download_args(self, listar):
        valores = self.validate_download_form()
        if valores is None:
            return None
        inicio, fin, nube = valores
        args = ["--inicio", inicio, "--fin", fin, "--nubosidad", nube, "--proyecto", self.project()]
        if listar:
            args.append("--solo-listar")
        return args

    def credentials_env(self):
        user = self.var_user.get().strip()
        password = self.var_pass.get()
        env = {}
        if user and password:
            env = {"CDSE_USER": user, "CDSE_PASSWORD": password}
        has_any = (
            env
            or (os.environ.get("CDSE_USER") and os.environ.get("CDSE_PASSWORD"))
            or (BASE_DIR / ".cdse_credentials").is_file()
        )
        return env, bool(has_any)

    def run_descarga_listar(self):
        args = self.download_args(listar=True)
        if args:
            self.run_script("descarga_copernicus.py", args)

    def run_descarga_real(self):
        args = self.download_args(listar=False)
        if not args:
            return
        env, available = self.credentials_env()
        if not available:
            messagebox.showwarning(
                "Faltan credenciales",
                "Introduce usuario y contraseña de Copernicus Data Space,\n"
                "o define CDSE_USER/CDSE_PASSWORD, o crea el archivo .cdse_credentials.",
            )
            return
        if not messagebox.askyesno(
            "Confirmar descarga",
            "Se descargarán todos los productos L2A que cumplan los filtros.\n"
            "Cada ZIP ocupa del orden de 0,5-1 GB; un intervalo de varios años\n"
            "puede llegar a decenas o cientos de GB.\n\n"
            "Se recomienda pulsar antes «Buscar Productos (Solo Listar)».\n\n"
            "¿Continuar con la descarga?",
        ):
            return
        self.run_script("descarga_copernicus.py", args, env=env)

    # ------------------------------------------------------------------
    # 2. Procesamiento y extracción
    # ------------------------------------------------------------------

    def run_sesion5(self):
        try:
            nube = float(self.var_nube_proc.get().replace(",", "."))
            umbral = float(self.var_umbral.get().replace(",", "."))
            opening = int(self.var_opening.get())
            if not 0 <= nube <= 100 or opening < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Parámetros no válidos", "Revisa nubosidad (0-100), umbral NDWI y radio de opening (entero ≥ 0).")
            return

        def requires():
            if not self.has_files(BASE_DIR / "Imagenes" / "zips_entrada", "*.zip"):
                return "No hay ZIP en Imagenes/zips_entrada. Descarga antes los productos (pestaña 1)."

        self.run_script(
            "sesion5.py",
            ["-p", self.project(), "--nubosidad", nube, "--umbral", umbral, "--opening-radio", opening],
            requires=requires,
        )

    def run_extract(self):
        try:
            closing = int(self.var_closing.get())
            if closing < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Parámetros no válidos", "El radio de closing debe ser un entero ≥ 0.")
            return

        def requires():
            if not self.has_files(self.output_dir() / "estimated_waterbodies_images", "*.tif"):
                return "No hay máscaras en output/estimated_waterbodies_images. Ejecuta antes el paso 1."

        self.run_script(
            "extract_shorelines.py",
            ["-p", self.project(), "--closing-radius", closing],
            requires=requires,
        )

    def run_calculate(self):
        args = ["-p", self.project(), "--no-plot"]
        if self.var_use_gt.get():
            gt = self.project_dir() / "ground_truth"
            if not self.has_files(gt, "*.csv"):
                messagebox.showwarning("Ground truth", f"No hay CSV de referencia en {gt}.")
                return
            args += ["-g", gt]

        def requires():
            if not (self.output_dir() / "estimated_waterbodies_edges" / "all_shorelines.csv").is_file():
                return "Falta all_shorelines.csv. Ejecuta antes el paso 2."

        def after():
            self.open_images(self.output_dir() / "estimated_erosion_accretion" / "transects_overview.png")

        self.run_script("calculate_erosion.py", args, requires=requires, on_success=after)

    def distances_required(self):
        if not (self.output_dir() / "estimated_erosion_accretion" / "shoreline_distances.csv").is_file():
            return "Falta shoreline_distances.csv. Ejecuta antes el paso 3."

    def run_analyze(self):
        self.run_script("analyze.py", ["-p", self.project()], requires=self.distances_required)

    def run_error(self):
        def requires():
            if not (self.output_dir() / "estimated_waterbodies_edges" / "all_shorelines.csv").is_file():
                return "Falta all_shorelines.csv. Ejecuta antes el paso 2."
            if not self.has_files(self.project_dir() / "ground_truth", "*.csv"):
                return "No hay CSV de referencia en la carpeta ground_truth del proyecto."

        def after():
            self.open_images(self.output_dir() / "estimated_error" / "error_by_transect.png")

        self.run_script("error_estimator.py", ["-p", self.project(), "--no-plot"], requires=requires, on_success=after)

    # ------------------------------------------------------------------
    # 3 y 4. Modelos
    # ------------------------------------------------------------------

    def run_eda(self):
        def after():
            self.open_images(BASE_DIR / "dinamica_erosion.png", BASE_DIR / "comparacion_modelos_parametricos.png")

        self.run_script("eda_and_parametric_models.py", ["--no-plot"],
                        requires=self.distances_required, on_success=after)

    def run_lstm(self):
        def after():
            self.open_images(BASE_DIR / "forecast_2025_comparison.png")

        self.run_script("forecasting_lstm.py", ["--no-plot"],
                        requires=self.distances_required, on_success=after)


if __name__ == "__main__":
    root = tk.Tk()
    app = CoastalControlApp(root)
    root.mainloop()
