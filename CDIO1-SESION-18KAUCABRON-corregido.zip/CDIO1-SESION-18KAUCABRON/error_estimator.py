"""
Validación de la costa estimada con una referencia externa (ground truth).

Dependencias:
    pip install numpy pandas scipy shapely geopandas rasterio matplotlib

Qué hace:
    1. Lee las costas estimadas (extract_shorelines.py -> all_shorelines.csv).
    2. Para cada fecha selecciona el CSV de referencia de fecha más próxima
       (projects/<proyecto>/ground_truth/ por defecto).
    3. Construye transectos perpendiculares a la referencia, recortada al
       polígono del proyecto, y mide la separación con signo hasta la costa
       estimada (mismo método y signo que calculate_erosion.py).
    4. Calcula n, sesgo, MAE y RMSE por fecha.

Salidas (projects/<proyecto>/output/estimated_error/):
    shoreline_distances.csv   date, reference_date, transect_id,
                              reference_x, reference_y, distance_m
    error_summary.csv         estadísticas y RMSE por fecha
    error_by_transect.png     separaciones por transecto

Uso:
    python error_estimator.py -p costa_principal
    python error_estimator.py -p costa_principal --date 2024-02-15 --no-plot

Importante:
    - Una referencia de otra fecha puede incluir cambios reales de la costa:
      el RMSE mezcla error de la estimación y evolución real (se informa
      la diferencia en días entre ambas fechas).
    - Las coordenadas estimadas y la referencia deben estar en un CRS
      proyectado en metros. La referencia se asume en EPSG:32631.
"""

import argparse
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pyproj import CRS, Transformer
from scipy.interpolate import splev, splprep
from shapely.geometry import LineString

import shoreline_utils as utils
from calculate_erosion import (
    SPATIAL_SPACING,
    TRANSECT_LENGTH,
    closest_ground_truth_file,
    load_project_aoi,
    ordered_line_coords,
    signed_intersection_distance,
)

REFERENCE_CRS = "EPSG:32631"


def read_reference_xy(csv_path):
    return (
        pd.read_csv(
            csv_path,
            sep=r"[\s,]+",
            engine="python",
            comment="%",
            header=None,
            usecols=[0, 1],
        )
        .apply(pd.to_numeric, errors="coerce")
        .dropna()
        .to_numpy(dtype=float)
    )


def build_transects(reference_xy, aoi):
    """Devuelve (puntos de referencia, normales unitarias)."""
    line = utils.build_ordered_linestring(reference_xy, ordered=True)

    if aoi is not None:
        geom = aoi.union_all() if hasattr(aoi, "union_all") else aoi.unary_union
        line = line.intersection(geom)

    coords = ordered_line_coords(line)
    if len(coords) < 4:
        raise ValueError(
            "La referencia no tiene suficientes puntos dentro del polígono."
        )

    tck, _ = splprep([coords[:, 0], coords[:, 1]], s=0)
    n_points = max(2, int(line.length / SPATIAL_SPACING))
    unew = np.linspace(0, 1, num=n_points)
    xs, ys = splev(unew, tck)
    dx, dy = splev(unew, tck, der=1)

    normals = np.column_stack((-np.asarray(dy), np.asarray(dx)))
    norms = np.linalg.norm(normals, axis=1)
    norms[norms == 0] = np.nan
    return np.column_stack((xs, ys)), normals / norms[:, None]


def measure(points, normals, estimated_line):
    half = TRANSECT_LENGTH / 2
    distances = np.full(len(points), np.nan)

    for i, ((px, py), normal) in enumerate(zip(points, normals)):
        if np.isnan(normal).any():
            continue
        transect = LineString([
            (px - normal[0] * half, py - normal[1] * half),
            (px + normal[0] * half, py + normal[1] * half),
        ])
        distances[i] = signed_intersection_distance(
            transect.intersection(estimated_line), px, py, normal
        )

    return distances


def to_reference_crs(frame):
    """Lleva los puntos estimados a EPSG:32631 si vienen en otro CRS."""
    target = CRS.from_user_input(REFERENCE_CRS)
    out = []

    for crs_text, group in frame.groupby("crs"):
        coords = group[["x", "y"]].to_numpy(dtype=float)
        source = CRS.from_user_input(crs_text)

        if source != target:
            xs, ys = Transformer.from_crs(
                source, target, always_xy=True
            ).transform(coords[:, 0], coords[:, 1], errcheck=True)
            coords = np.column_stack((xs, ys))

        out.append((group.index, coords))

    result = frame[["x", "y"]].copy()
    for index, coords in out:
        result.loc[index, ["x", "y"]] = coords
    return result


def main(project, ground_truth=None, only_date=None, show_plot=True):
    project_dir = utils.project_path(project)
    out_dir = project_dir / "output" / "estimated_error"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not show_plot:
        plt.switch_backend("Agg")

    csv_path = project_dir / "output" / "estimated_waterbodies_edges" / "all_shorelines.csv"
    if not csv_path.is_file():
        raise SystemExit(f"No existe {csv_path}. Ejecuta antes extract_shorelines.py.")

    df = pd.read_csv(csv_path)
    if df.empty:
        raise SystemExit("all_shorelines.csv no contiene puntos.")

    if "crs" not in df.columns:
        df["crs"] = REFERENCE_CRS
    df[["x", "y"]] = to_reference_crs(df)

    dates = sorted(df["date"].unique())
    if only_date:
        if only_date not in dates:
            raise SystemExit(
                f"La fecha {only_date} no está en all_shorelines.csv. "
                f"Disponibles: {', '.join(dates)}"
            )
        dates = [only_date]

    gt_dir = ground_truth or (project_dir / "ground_truth")
    aoi = load_project_aoi(project_dir)

    transect_cache = {}
    rows, summary = [], []

    for date in dates:
        target = datetime.strptime(date, "%Y-%m-%d").date()
        ref_date, ref_path = closest_ground_truth_file(gt_dir, target)
        gap_days = abs((ref_date - target).days)

        if ref_path not in transect_cache:
            transect_cache[ref_path] = build_transects(
                read_reference_xy(ref_path), aoi
            )
        points, normals = transect_cache[ref_path]

        coords = df.loc[df["date"] == date, ["x", "y"]].to_numpy(dtype=float)
        if len(coords) < 2:
            print(f"{date}: puntos insuficientes, se omite.")
            continue

        estimated_line = utils.build_ordered_linestring(coords, False)
        distances = measure(points, normals, estimated_line)
        valid = distances[np.isfinite(distances)]

        print(
            f"{date}: referencia {ref_date} ({gap_days} días de diferencia), "
            f"{len(valid)}/{len(distances)} transectos válidos"
        )

        for i, d in enumerate(distances):
            rows.append({
                "date": date,
                "reference_date": ref_date.isoformat(),
                "transect_id": i,
                "reference_x": points[i, 0],
                "reference_y": points[i, 1],
                "distance_m": d,
            })

        summary.append({
            "date": date,
            "reference_date": ref_date.isoformat(),
            "gap_days": gap_days,
            "n_valid": int(len(valid)),
            "n_transects": int(len(distances)),
            "coverage_ratio": len(valid) / len(distances),
            "bias_m": float(valid.mean()) if len(valid) else np.nan,
            "mae_m": float(np.abs(valid).mean()) if len(valid) else np.nan,
            "rmse_m": float(np.sqrt(np.mean(valid ** 2))) if len(valid) else np.nan,
        })

    if not rows:
        raise SystemExit("No se pudo calcular ninguna separación.")

    pd.DataFrame(rows).to_csv(out_dir / "shoreline_distances.csv", index=False)
    summary_df = pd.DataFrame(summary)
    summary_df.to_csv(out_dir / "error_summary.csv", index=False)

    print("\nRMSE por fecha:")
    print(summary_df[["date", "reference_date", "gap_days", "n_valid", "bias_m", "rmse_m"]]
          .round(3).to_string(index=False))

    fig, ax = plt.subplots(figsize=(12, 5))
    for date, group in pd.DataFrame(rows).groupby("date"):
        ax.plot(group["transect_id"], group["distance_m"], label=date)
    ax.set_xlabel("Transect ID")
    ax.set_ylabel("Separación respecto a la referencia (m)")
    ax.set_title("Error de la costa estimada por transecto")
    ax.grid(True)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir / "error_by_transect.png", dpi=150)

    if show_plot:
        plt.show()
    else:
        plt.close(fig)

    print(f"\nResultados guardados en: {out_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Compara la costa estimada con una referencia externa."
    )
    parser.add_argument("-p", "--project", required=True)
    parser.add_argument("-g", "--ground-truth", help="Carpeta con los CSV de referencia.")
    parser.add_argument("--date", help="Validar solo esta fecha (YYYY-MM-DD).")
    parser.add_argument("--no-plot", action="store_true")
    args = parser.parse_args()

    main(args.project, args.ground_truth, args.date, show_plot=not args.no_plot)
